# PLC的解释

**Number of Power Line Cycles"** 的缩写，中文可译为 **"电源周期数"** 或 **"工频周期数"**。


![image.png](assets/image.png)
