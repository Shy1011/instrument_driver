# Name rules
This is the rule everyone should follow when we name the instrument object
in our codes.

```python
# The basic name rule should be like this :
"""
Brand_InstrumenMode_Fuction1_Function2_Num, such as : 

Gwinstek_Dmm9061_VoltMeasure_CurMeasure_1
Keysight_Dmm34461A_VoltMeasure _1
Keithley_SMU2450_ForceCurMeaVolt_1

"""
```



